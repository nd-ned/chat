import { contacts } from "../static-data";

export default (state = contacts, action) => {
  return state
}