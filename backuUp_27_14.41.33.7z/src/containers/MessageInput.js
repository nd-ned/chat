import React from "react";
import store from "../store";
import "./MessageInput.css";
import { setTypingValue, sendMessage } from "../actions";
import { socket } from "../config/socketConnection"

const MessageInput = ({ value }) => {

    const handleChange = e => {
        store.dispatch(setTypingValue(e.target.value));
    };

    const state = store.getState();

    const handleSubmit = e => {
        e.preventDefault();
        console.log(socket)
        const { typing, activeUserId } = state;
        socket.emit('new message', {message: typing})
        store.dispatch(dispatcher => {
            dispatcher(sendMessage(typing, activeUserId))
        });
    };

    return (
        <form className="Message" onSubmit={handleSubmit}>
            <input
                className="Message__input"
                onChange={handleChange}
                value={value}
                placeholder="write a message"
            />
        </form>
    );
};

export default MessageInput;