import React from 'react';


import ReactDOM from "react-dom";
import "./index.css";
import App from "./containers/App";
import registerServiceWorker from "./registerServiceWorker";
import store from "./store";

// import openSocket from 'socket.io-client';
// const socket = openSocket('http://localhost:3000');
import { addContact } from "./actions/index"
import { socket } from "./config/socketConnection"


const render = () => {

  return ReactDOM.render(<App />, document.getElementById("root"));
};

render();
store.subscribe(render);
registerServiceWorker();

const state = store.getState();

/**
 * SOCKETING
 */
socket.on('new connection', (data) => {
  console.log("%c New user ID: " + data, "font-size: 24px", state)
  socket.emit('add user', {
    username: state.user.name,
    userId: data,
    socketId: socket.id,
    profile_pic: state.user.profile_pic,
    status: state.user.status
  });
})


socket.on('login', users => {
  store.dispatch(dispatcher => {
    dispatcher(addContact(users))
  });
})

